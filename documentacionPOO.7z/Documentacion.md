# **Documentación del Proyecto**
- ## **Autor:** Carlos Eduardo Soriano Molina
- ## **Número de Cuenta:** 20201004421
- ## **Fecha:** 21/4/2022
--------------------------------------------------------------------------------------------------------------------------
## Algunos conceptos importantes:
- LinkedList: colección de nodos que de manera conjunta forman una secuencia lineal.
- Tree: es un tipo de dato abstracto que almacena elementos jerárquicamente.
- Map: tipo de dato abstracto diseñado para almacenar y recuperar valores eficientemente basado en una clave(key) de búsqueda de identificación única para cada una.
    - Entradas: almacenan pares (k,v), donde k es la llave y v su respectivo valor.
- Graph: es una colección de vértices y aristas.
    - Vértice: objeto que almacena un elemento arbitrario proporcionado por el usuario.
    - Arista: también almacena un objeto asociado, según su vértice.
> Data Structures & Algorithms. Michael T. Goodrich, Roberto Tamassia and Michael H. Goldwasser.
--------------------------------------------------------------------------------------------------------------------------
## Planeación e Ideas
1. Tener en cuenta algunas de las siguientes clases abstractas, proporcionadas por el docente, en mi programa:
    - LinkedList
    - Node
    - Tree, BST
    - Map, Json
    - ConsoleSimulator
    - MatrixManager, CSVManager, FileManager
2. Sacar provecho de la literatura de la clase de la mejor manera, así como utilizar algunos códigos y librerías proporcionados por los autores del libro Data Structures & Algorithms.
3. Recordar y seguir los pasos que el licenciado nos trató de enseñar para que mi programa sea robusto y cumpla con todas las funcionalidades requeridas.
4. Tratar de realizar el código del programa, lo más eficiente posible en tiempo de ejecución.
5. Reutilizar la mayor cantidad de código al alcance, como complemento al punto anterior.
6. Mediante análisis propio, esfuerzo y dedicación a la tarea, aplicar los conocimientos vistos en clase y de prácticas anteriores para poder realizar un trabajo a la altura de lo solicitado.

