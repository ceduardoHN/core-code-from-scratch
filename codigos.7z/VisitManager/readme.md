EJERCICIO
===
Aplicando los conocimientos y nomenclaturas de la clase, haga un programa de JSP que permite realizar un conteo de visitas mediante sesiones.
- O sea, que cada vez que el usuario ingresa a la pagina o haga un refresh, se cuente cuantas veces han ocurrido estas dos accciones.
- Cada vez que se refresque la pagina se esta refrescando el index.jsp, donde debe imprimirse el resultado del conteo de las visitas.