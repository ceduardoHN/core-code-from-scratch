# **Documentación del Proyecto**
- #### **Autor:** Carlos Eduardo Soriano Molina
- #### **Número de Cuenta:** 20201004421
- #### **Fecha:** 30/11/2022
# **ANÁLISIS Y DISEÑO ORIENTADO A OBJETOS**
## **DESCRIPCIÓN BREVE DEL EJERCICIO**
Se nos presenta un ejercicio que requiere de conocimientos sobre Programacion Orientada a Objetos, para realizar un "Sistema de Registro de Documentos"; donde en una única Vista se centralizan todas las funcionalidades del sistema. Estas funcionalidades son:
- Debe existir un menú superior que permita crear un nuevo registro de documento. 
    - Cuando se requiera esta acción, debe abrirse una "Ventana Modal" que reciba todos los datos del registro.
- Estos datos deben guardarse en un archivo de modelo de datos propio que el programa deberá leer.
- Debe existir un menú superior que permita limpiar por completo el modelo de datos. 
- Debe existir un menú superior que permita visualizar la información del autor del sistema, por medio de una "Ventana Modal".
- Mostrar todos los registros leídos desde el modelo de datos usando un elemento "scroll vertical".
- En el elemento "scroll vertical", se sugiere lo siguiente:
    - Mostrar el tipo de registro, su número asociado y el responsable que lo agregó a la lista.
    - Para ver la descripción del registro, se debe implementar un botón "Ver descripción", que por medio de una "Ventana Modal" muestre su contenido.
- Mostrar la cantidad total de registros o documentos existentes en el sistema.
--------------------------------------------------------------------------------------------------------------------------
## **PROPUESTA DE SOLUCIÓN**
Con los objetos de tipo HttpServletRequest request y HttpSession session, y sus respectivos métodos y atributos, implementar el sistema para que pueda realizar las funcionalidades requeridas. Por ejemplo por medio de los métodos "getAttribute()" y "setAttribute()", POST y GET, send(), entre otros.

### **Componentes js:**
1. Por medio de una clase (e.g. Action), implementar los funcionamientos que los diferentes componentes de la página deben implementar, como ser:
- Cuando se de click en los menús desplegables "Inicio" o "Acerca De", mostrar sus respectivas opciones, ocultas dentro de ellos.
- Al dar click en la opción "Agregar/Extraer un Documento", "Limpiar el Modelo de Datos" o "Acerca De", desplegar la "ventana modal" correspondiente.
- Cada vez que se agregue un nuevo registro, incrementar el número en el contador de registros del sistema.
2. Usar una clase (e.g. Validator) que se encargue de verificar, en el FrontEnd, si la información que se intenta escribir en los apartados de cada registro sea válida para su escritura en el modelo de datos.
3. Clase DynamicForm junto con un elemento dynamicSection para implementar la funcionalidad de mostrar el número de registros existentes en el sistema.

### **Componentes java:**
1. Clases FileManager y FileManagerResponse para la creación, lectura y escritura de archivos en disco. Tambien deben encargarse de mostrar un status/estado en los intentos de creación de archivos; notificar en caso de que ocurra un error y ademas mostrar la ruta/path donde son creados los archivos en el almacenamiento interno.

<img src="">

2. Objetos con un comportamiento, características y funcionalidad según los conceptos DTO Y DAO, que permiten la transferencia y acceso a la información por medio de un modelo de datos.
3. En el BackEnd, un objeto Validator, que verifica que la información o datos recibidos desde el FrontEnd sea correcta para su escritura en el modelo de datos.

<img src="">



### **Componente jsp:**
Archivo donde se encapsulan todas las funcionalidades del sistema (index.jsp). 

### **Componentes html:**(en archivo jsp)
1. Utilizar la librería "bootstrap" (agregándola con los links de los componentes .css y .js correspondientes) como guía y apoyo para añadir los elementos: 
- scroll vertical: donde se mostrará la información de los registros del sistema
- navbar: aquí estaran los menús desplegables "Inicio", donde estarán las opciones "Agregar/Extraer un Documento" y "Limpiar el Modelo de Datos"; y "Acerca De", el cual mostrará la información del autor mediante la opción "Autor".
- ventanas modales: las cuales serán variadas segun los requerimientos de cada opción donde se utilicen.
2. Mediante un archivo style.css, especificar los tipos de letra, colores, tamaños, ubicación y otras características de los elementos tipo DOM (Document Object Model) que implementemos y que el sistema posea; como ser los componentes "div", "section", "input", "form", entre otros.